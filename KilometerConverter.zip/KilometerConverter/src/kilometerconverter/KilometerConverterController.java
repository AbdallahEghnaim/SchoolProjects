/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package kilometerconverter;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author Megha Patel
 */
public class KilometerConverterController {
   @FXML
    private Button convertButton;

   @FXML
   private TextField kilometerTextField;
  
   @FXML
   private Label outputLabel;
   
   @FXML
   private Label promptLabel;
   
   //optional method, this method is called when FXML file is loaded
   public void initialize(){
   //Perform necessary initialization here
   }
   
   //Event Listener for the convertButton
   public void convertButtonListener()
   {
       final double CONVERSION_FACTOR=0.6214;
       
       //get the value for entered kilometer as string
       String str=kilometerTextField.getText();
       
       //Conversion of kilometer into miles
       double miles=Double.parseDouble(str)*CONVERSION_FACTOR;
   
       //display converted output
       outputLabel.setText(str+" kilometer is "+ miles+ " miles.");
   }
   
   
}
