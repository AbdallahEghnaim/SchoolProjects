/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package abstractdemo;

/**
 *
 * @author Megha Patel
 */
abstract class abstract1
{
    abstract public void disp();
    abstract public void show();

}

abstract class abstract2 extends abstract1
{
    abstract public void disp1();
    @Override
    public void show()
    {
        System.out.println("abstract2 implemented it");
    }

}

class concrete extends abstract2
{

    @Override
    public void disp1() {
        System.out.println("Concrete:disp1 called");
    }

    @Override
    public void disp() {
        System.out.println("concrete:disp called");
    }
    public void print()
    {
        System.out.println("concrete:print called");
    }
}



public class AbstractDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        concrete obj=new concrete();
        obj.disp();
        obj.disp1();
        obj.show();
        obj.print();
        
        abstract2 obj1=new concrete();
        
        obj1.disp();
        obj1.disp1();
        ((concrete)obj1).print();//unique method of concrete class
    }

}

