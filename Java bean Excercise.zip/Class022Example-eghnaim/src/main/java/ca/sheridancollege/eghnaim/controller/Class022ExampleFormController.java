package ca.sheridancollege.eghnaim.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.eghnaim.beanss.User;



@Controller 

public class Class022ExampleFormController {
	
	
	@GetMapping("/index")

	public String index() {

	return "index";

	}

	@GetMapping("/userInput")

	public String userInputForm(Model model) {

	model.addAttribute("user", new User());

	return "userInput";

	}

	@PostMapping("/userInput")

	public String userInputSubmit(@ModelAttribute User user, Model model) {

	model.addAttribute("user", user);

	return "registeredUsers";

	}

}
