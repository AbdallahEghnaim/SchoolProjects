package ca.sheridancollege.eghnaim.beanss;

public class User {

// User object properties

private String userName;

private String email;

private String phone;

// no-arg constructor

public User() {

}

// Setter methods

public void setUserName(String name) {

this.userName = name;

}

public void setEmail(String email) {

this.email = email;

}

public void setPhone(String phone) {

this.phone = phone;

}



public String getUserName() {

return this.userName;

}

public String getEmail() {

return this.email;

}

public String getPhone() {

return this.phone;

}

}