<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    
    <body>
      
        
      <?php
       echo"<h1>Slots<h1>";
       
       $data = rand(1, 7).".png";
       $data2 = rand(1, 7).".png";
       $data3 = rand(1, 7).".png";
          echo"<img src = $data>";
           echo"<img src = $data2>";
           echo"<img src = $data3>";
           echo"<br>";
           
           if ($data === $data2 && $data === $data3 ){
               
               echo" yaayyyy Jackpot";
               
           } Elseif ($data=== $data2 || $data === $data3|| $data2 === $data3){
               
               echo"you win";
           } else{
               echo"you lose!!!";
               
           } 
           echo"<br>";
           echo"press link to play again";
           echo"<br>";
           echo"<a href= http://eghnaim.dev.fast.sheridanc.on.ca/Slots/index.php>reply press here</a>";
           
        ?>
        
      
        
        
    <body>
</html>
