/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package fileread;

import java.io.*;

/**
 *
 * @author Megha Patel
 */
public class FileRead {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        
        File file=new File("insertinput.txt");
        
        //creates FileWriter Object
        FileWriter writer=new FileWriter(file);
        //Write contents to the file
        writer.write("This is an example of FileReader \n and FileWriter");
        writer.flush();
        writer.close();
        
        FileReader fileRead=new FileReader(file);
        int i=(int)file.length();
        char[] arr=new char[i];
        
        fileRead.read(arr);
        for(char c:arr)
        {
            System.out.print(c);
        }
        fileRead.close();
    }

}
