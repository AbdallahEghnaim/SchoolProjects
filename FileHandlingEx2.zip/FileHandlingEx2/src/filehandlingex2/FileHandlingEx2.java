/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package filehandlingex2;

import java.io.*;

/**
 *
 * @author Megha Patel
 */
public class FileHandlingEx2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String data="Hello This is my first file";
        try{
                //write data into file
                FileOutputStream output=new FileOutputStream("src/filehandlingex2/output.txt");
                byte[] arr=data.getBytes();
                //writes byte to the file
                output.write(arr);
                output.close();
                
                
                //read data from file
                
                FileInputStream input=new FileInputStream("src/filehandlingex2/output.txt");
                System.out.println("File data are as follows: ");
                
                //Reads the first byte
                int i=input.read();
                
                while(i!=-1)
                {
                    System.out.print((char)i);
                    i=input.read();
                }
                input.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}
