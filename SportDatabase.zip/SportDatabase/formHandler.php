<?php

 if(isset($_POST["delete"])){
     echo "<h1>Delete Page</h1><form action='delete.php' method='POST' >"
     . "<h2>what would you like to delete</h2>"
     . "name:<input type ='text'name='delete'>"
     ."<button type='submit'>submit</button>"
     . "</form> ";
     
 }
 if (isset($_POST["insert"])){
   echo"<h1>Insert Page</h1>"
     . "<h2>whhat would you like to insert<h2>"
     ."<form action='insert.php' method='POST'><br>"      
     ."name:<input type='text' name ='name'><br>"
     . "player count<input type='text' name='playercount'><br> "    
     ."indoor:<input type='text' name='indoor'><br>"
     ."referee count:<input type='text' name='refcount'><br>"      
     ."origin:<input type='text' name ='countryOfOrigin'><br>"
     ."<input type ='submit' name= 'submit'><br>"
     ."</form><br>";
     
 }
 if(isset($_POST["update"])){
     echo"<h1>Update page</h1>"
     ."<form action='update.php' method='POST'>"
             . "Where:sport_id===<input type='text' name='key'><br>"
             . "new name:<input type='text' name ='name'><br>"
             ." new indoor: <input type='text' name ='indoor'><br>"
             ."new origins:<input type='text' name='countryOfOrigin'><br>"
             ."<input type='submit' name ='submit'>"
             . "</form><br>" ;
    
 }
