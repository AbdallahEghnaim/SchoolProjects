<?php
require('connect.php');
?>
<?php 

        
        try{
            $dbCONN = new PDO("mysql:host=localhost;dbname=eghnaim_Sports", $username, $passwd);
            echo"welcome to the Sports database";
            
        }catch(PDOException $error){
            
            echo"not connected due to :".$error->getMessage();            
        }
        
?>

<?php

   if ( isset($_POST[name])){
       
       $sql = "update sport SET name='$_POST[name]' where sport_id=$_POST[key] ";
       $stmt=$dbCONN->prepare($sql);
       $execok=$stmt->execute();
       
  if ($execok){
      
      echo"your name was updated<br>";
      
  }else{
      
     echo'your name was not updated<br>';
    
   }
   
  }
  
  if(isset($_POST[playercount])){
      
      $sql="UPDATE sport SET player_count=$_POST[playercount] where sport_id ==$_POST[key]";
      $stmt= $dbCONN ->prepare($sql);
      $execok=$stmt->execute();
    if ($execok){
      
      echo"playercount was updated<br>";
      
  }else{
      
     echo'your playercount was not updated<br>';
     
   }      
  }
  
  if(isset($_POST[indoor])){
     
       
      $sql="UPDATE sport SET indoor ='$_POST[indoor]' where sport_id =$_POST[key]";
      $stmt= $dbCONN ->prepare($sql);
      $execok=$stmt->execute();
      
      if ($execok){
      
      echo"you indoor record was updated<br>";
      
  }else{
      
     echo'your indoor record was not updated<br>';
     
   }
          
  }
       if(isset($_POST[refcount])){
     
       
      $sql="UPDATE sport SET referee_count=$_POST[refcount] where sport_id =='$_POST[key]'";
      $stmt= $dbCONN ->prepare($sql);
      $execok=$stmt->execute();
      
      if ($execok){
      
      echo"your ref count was updated <br>";
      
  }else{
      
     echo'your refcount was not updated <br>';
     
   }
      
      
  }
  
  
   if(isset($_POST[countryOfOrigin])){
    
       
      $sql="UPDATE sport SET origin='$_POST[countryOfOrigin]'where sport_id =$_POST[key]";
      $stmt= $dbCONN ->prepare($sql);
      $execok=$stmt->execute();
      
      if ($execok){
      
      echo"your origin was updated<br>";
      
  }else{
      
     echo'your origin was not updated <br>';
     
   }
      
      
  }
       
       
 
       
   
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
echo""
  . "<form action='index.php' method ='POST'>"
        . "<button type='submit'>homepage</button>"
        ."</form>";


