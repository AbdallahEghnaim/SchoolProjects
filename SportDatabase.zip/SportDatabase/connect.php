<?php
$username="eghnaim_Abs";
$passwd="5S{3Sqc^IhaJ"; // password for database 
$hostname="localhost";
        

    