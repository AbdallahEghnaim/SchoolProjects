
<?php
require('connect.php');
?>
<?php
        
        try{
            $dbCONN = new PDO("mysql:host=localhost;dbname=eghnaim_Sports", $username, $passwd);
            echo"welcome to the Sports database";
            
        }catch(PDOException $error){
            
            echo"not connected due to :".$error->getMessage();            
        }
        ?>

<?php
if(isset($_POST[name])&& isset($_POST[playercount])&& isset($_POST[indoor])&& isset($_POST[refcount]) && isset($_POST[countryOfOrigin])){
$sql="INSERT INTO sport (name,player_count,indoor,referee_count,origin) VALUES ('$_POST[name]','$_POST[playercount]','$_POST[indoor]','$_POST[refcount]','$_POST[countryOfOrigin]')" ;
$stmt= $dbCONN->prepare($sql);
$execok= $stmt->execute();
 if($execok){
     
     echo"record was inserted";
     
 }else{
     
     echo "you must enter all fields appropriatly";
     $debug=$dbCONN->errorCode();
     echo $debug;
     
 }

}
echo""
  . "<form action='index.php' method ='POST'>"
        . "<button type='submit'>homepage</button>"
        ."</form>";