<!DOCTYPE html>
<?php require('connect.php'); ?>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
   
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>choose your operation</h1>
        <form action='formHandler.php' method='post'>
        <div>
        <input type='radio' name ='delete'>delete</input><br>
          <input type='radio' name ='update'>update</input><br>
          <input type='radio' name='insert'> insert</input><br> 
          </form>
         <button type='submit'>submit</button>
         <form action='view.php'method='post'>
         <button type='submit' name='view'>view all </button>
         </form>
         </div>
         
        
       


     
    </body>
</html>

     
