<!doctype html>
<?php
require ('connect.php');
?>
<style>
<?php
$css= file_get_contents('main.css');
echo $css;
?>
 </style>
<html>
    <head>
        <meta charset="UTF-8">
        <title>my database</title>
        
        <style> 
           table{border-style:solid;}
           th {border-style:solid;}
    
</style>
    </head>
    <body>



<?php
        


        try{
            $dbCONN = new PDO("mysql:host=localhost;dbname=eghnaim_Sports", $username, $passwd);
            echo"welcome to the Sports database";
            
        }catch(PDOException $error){
            
            echo"not connected due to :".$error->getMessage();            
        }
        ?>
<br>
 <table>
     <tr>
 <th>sport_id</th>
 <th>name</th>
 <th>player_count</th>
 <th>indoor</th>
 <th>referee_count</th>
 <th>origin</th>
     </tr>
 </table>

<?php

    $sql = "SELECT * from sport";

$stmt = $dbCONN->prepare($sql);
$execok = $stmt->execute();
    echo"<br>";

     
do {
    
    echo "<table><tr><th> ".$row[sport_id]."</th><th>".$row[name]."</th><th>".$row[player_count]."</th><th>".$row[indoor]."</th><th>".$row[referee_count]."</th><th>".$row[origin]."</th></tr></table>";
 
    
}while( $row = $stmt->fetch());
        
echo""
  . "<form action='index.php' method ='POST'>"
        . "<button type='submit'>homepage</button>"
        ."</form>";
?>




