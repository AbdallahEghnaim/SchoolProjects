<?php
require('connect.php')
  ?>
<?php
        
        try{
            $dbCONN = new PDO("mysql:host=localhost;dbname=eghnaim_Sports", $username, $passwd);
            echo"welcome to the Sports database";
            
        }catch(PDOException $error){
            
            echo"not connected due to :".$error->getMessage();            
        }
        ?>
<?php

 if(isset($_POST[delete])){
echo"<br>";
$sql="DELETE from sport WHERE name='$_POST[delete]' ";
     
$stmt=$dbCONN->prepare($sql);

$execok=$stmt->execute();
 }
 
if($execok){
    echo"delete was completed successfully";
   
}else{
echo" delete was unsuccessful ";
 $debug=$dbCONN->errorCode();
 echo $debug;
}
 
 
 echo""
  . "<form action='index.php' method ='POST'>"
        . "<button type='submit'>homepage</button>"
        ."</form>";